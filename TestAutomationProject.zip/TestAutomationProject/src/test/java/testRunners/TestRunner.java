package testRunners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

    @RunWith(Cucumber.class)
    @CucumberOptions(
            features = {"src/test/resources/Features"},
            glue = {"stepdefinitions"},
            plugin = {"pretty","html:target/cucumber","json:target/site/report.json"}
           )

    public class TestRunner {

}
